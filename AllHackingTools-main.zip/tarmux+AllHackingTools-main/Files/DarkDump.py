import requests
import os
import time
import random
import sys
os.system("clear")
os.system("cd")
os.system("cd AllHackingTools")
os.system("bash Logo.sh")
os.system("cd darkdump")
site=int(raw_input("\033[1;33;40mOnion Search:"))
os.system("python3 darkdump.py '+site")
os.system("cd")
os.system("cd AllHackingTools")
