g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"

pwd
cd 
cd 
cd ..
cd usr
mkdir AllHackingTools
cd
cd
cd AllHackingTools
cd src
cp ngrok.sh /data/data/com.termux/files/usr
cd
cd 
cd AllHackingTools
cd Files
bash PackagesInstaller.sh
cd
cd
cd AllHackingTools
bash Files/CamHackFiles.sh
bash Files/AndroidFiles.sh
bash Files/SocialFiles.sh
bash Files/MailFiles.sh
bash Files/WebFiles.sh
bash Files/PhishingFiles.sh
bash Files/RouterFiles.sh
bash Files/SQLinjectionFiles.sh
bash Files/SpamFiles.sh
bash Files/AnalystickFiles.sh
bash Files/WordlistGeneratorFiles.sh
bash Files/XSSAttackFiles.sh
echo '
██╗███╗░░██╗░██████╗████████╗░█████╗░██╗░░░░░██╗░░░░░██╗███╗░░██╗░██████╗░
██║████╗░██║██╔════╝╚══██╔══╝██╔══██╗██║░░░░░██║░░░░░██║████╗░██║██╔════╝░
██║██╔██╗██║╚█████╗░░░░██║░░░███████║██║░░░░░██║░░░░░██║██╔██╗██║██║░░██╗░
██║██║╚████║░╚═══██╗░░░██║░░░██╔══██║██║░░░░░██║░░░░░██║██║╚████║██║░░╚██╗
██║██║░╚███║██████╔╝░░░██║░░░██║░░██║███████╗███████╗██║██║░╚███║╚██████╔╝
╚═╝╚═╝░░╚══╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚══════╝╚══════╝╚═╝╚═╝░░╚══╝░╚═════╝░
'|lolcat -a -d 8 -s 35.0 -p 1.7
bash Files/PassworldFiles.sh
bash Files/DarkSearchFiles.sh
bash Files/IpFiles.sh
bash Files/TermuxSFiles.sh
bash Files/OtherFiles.sh
cd
cd
cd AllHackingTools
cd Files
bash TypeTermuxAndLinux.sh
cd
cd
pkg upgrade
apt list
sleep 0.4
clear
sleep 0.2
cd
cd 
clear
python3 AllHackingTools/.check/ServerStatusCheck.py
cd
cd
bash AllHackingTools/.check/ServerConfig.sh
clear
cd
cd 
cd && cd AllHackingTools && python2 src/TerminalBanner.py
cd
cd
cd AllHackingTools
cd Tool
chmod +x folder
chmod +x os
mv folder /data/data/com.termux/files/home/AllHackingTools
mv os /data/data/com.termux/files/home/AllHackingTools
cd
cd
cd AllHackingTools
cd Files
python get.py
cd
cd
cd AllHackingTools
cd .logs 
pip freeze > requirements.txt
cd
cd
cd /data/data/com.termux/files/usr/bin
chmod +x msdc
chmod +x msdconsole
chmod +x msdconsoleUPD
chmod +x standart
chmod +x edit
chmod +x Theme
chmod +x theme
chmod +x m
chmod +x ms
chmod +x msd
chmod +x sys
chmod +x system
chmod +x msdServer
chmod +x folder
cd
python3 -m pip install NPhish
cd
python3 -m pip install paramiko
python3 -m pip install future
python3 -m pip install rich
rm -rf ngrok
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip
unzip ngrok-stable-linux-amd64.zip
rm ngrok-stable-linux-amd64.zip
chmod 755 ngrok
mv ngrok /usr/bin/
cd
cd
echo '
██████╗░░█████╗░███╗░░██╗███████╗
██╔══██╗██╔══██╗████╗░██║██╔════╝
██║░░██║██║░░██║██╔██╗██║█████╗░░
██║░░██║██║░░██║██║╚████║██╔══╝░░
██████╔╝╚█████╔╝██║░╚███║███████╗
╚═════╝░░╚════╝░╚═╝░░╚══╝╚══════╝
Developer : mishakorzhik
created on: 23 05 2021
code      : python, bash, php
'|lolcat -p 1.0
echo -e $b"[^_^]"$w" AllHackingTools donate: "$g"https://www.buymeacoffee.com/misakorzik"$w
echo -e $b"[^_^]"$w" SuccesFull Installed: "$g"AllHackingTools"$w
echo -e $b"[^_^]"$w" Run Command to Start Tool: "$g"msdc & msdconsole"$w
echo -e $b"[^_^]"$w" Command to Update Tool: "$g"msdconsoleUPD"$w
cd
cd






