g="\033[1;32m"

echo "$g"
figlet -f bloody Hacking
