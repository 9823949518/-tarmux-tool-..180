echo '
  01) ~ Quick Start - on/off
  02) ~ Servers Setting
  03) ~ New ExtraKeys0
  04) ~ New ExtraKeys1
  05) ~ Add AllHackingTool to startup
  06) ~ View MySystem Process - ProcessExplorer
  07) ~ Exit System - log out AllHackingTool
  08) ~ Back To MainMenu - go to the home menu '| lolcat -p 1.4
